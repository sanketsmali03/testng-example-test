package com.baseclasses;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.asserts.SoftAssert;

public class FormBase extends CodeBase {
    SoftAssert softAssert = new SoftAssert();
    public void EnterFirstName() {
        //String select = Keys.chord(Keys.COMMAND, Keys.CONTROL, "a");
        String select = Keys.chord(Keys.SHIFT, Keys.ARROW_UP);
        
        // Ensure that you can find the firstname element
        WebElement FirstName = driver.get().findElement(By.name("firstname"));
        boolean FirstNameVisible = FirstName.isDisplayed();
        softAssert.assertTrue(FirstNameVisible);
        //click into the box, send a blank value and then click anywhere on the field, check the error message shows
        FirstName.sendKeys("");
        WebElement blanket = driver.get().findElement(By.xpath("//html"));
        blanket.click();
        WebElement FirstNameError = driver.get().findElement(By.xpath("//*[contains(text(), 'Please enter a first name')]"));
        boolean FirstNameBlankErrorVisible = FirstNameError.isDisplayed();
        softAssert.assertTrue(FirstNameBlankErrorVisible);

        // Send numbers into FirstName, and then check that the proper error messages are displayed.
        FirstName.sendKeys("123");
        blanket.click();
        WebElement FirstNameNumbers = driver.get().findElement(By.xpath("//*[contains(text(), 'Please enter a valid first name')]"));
        boolean FirstNameNumbersErrorVisible = FirstNameNumbers.isDisplayed();
        softAssert.assertTrue(FirstNameNumbersErrorVisible);
        FirstName.clear();

        FirstName.sendKeys(select);
        FirstName.sendKeys(Keys.DELETE);

        // Send special characters into FirstName, and then check that the proper error messages are displayed.
        FirstName.sendKeys("%<$£!");
        blanket.click();
        WebElement FirstNameSpecial = driver.get().findElement(By.xpath("//*[contains(text(), 'Please enter a valid first name')]"));
        boolean FirstNameSpecialErrorVisible = FirstNameSpecial.isDisplayed();
        softAssert.assertTrue(FirstNameSpecialErrorVisible);
        FirstName.clear();

        FirstName.sendKeys(select);
        FirstName.sendKeys(Keys.DELETE);

        // Send 51 keys into the First Name field, and check that the proper error message is displayed, then clear down the box.
        FirstName.sendKeys(StringUtils.repeat("a", 51));
        System.out.println("51 Keys have been input");

        WebElement FiftyOneKeys = driver.get().findElement(By.xpath("//*[contains(text(), 'First name cannot be longer than 50 characters')]"));
        boolean FiftyOneKeysErrorVisible = FiftyOneKeys.isDisplayed();
        softAssert.assertTrue(FiftyOneKeysErrorVisible);
        FirstName.sendKeys(select);
        FirstName.sendKeys(Keys.DELETE);

        FirstName.sendKeys("ABC1");
        FirstName.sendKeys(select);
        FirstName.sendKeys(Keys.DELETE);

        FirstName.sendKeys("Test");

        softAssert.assertAll();
    }

    public void EnterSurname() {
        //String select = Keys.chord(Keys.COMMAND, Keys.CONTROL, "a");
        String select = Keys.chord(Keys.SHIFT, Keys.ARROW_UP);
        
        // Ensure that you can find the lastname element
        WebElement SecondName = driver.get().findElement(By.name("lastname"));
        boolean SecondNameVisible = SecondName.isDisplayed();
        softAssert.assertTrue(SecondNameVisible);
        //click into the box, send a blank value and then click anywhere on the field, check the error message shows
        SecondName.sendKeys("");
        WebElement blanket = driver.get().findElement(By.xpath("//html"));
        blanket.click();
        WebElement SecondNameError = driver.get().findElement(By.xpath("//*[contains(text(), 'Please enter a last name')]"));
        boolean SecondNameBlankErrorVisible = SecondNameError.isDisplayed();
        softAssert.assertTrue(SecondNameBlankErrorVisible);

        // Send numbers into FirstName, and then check that the proper error messages are displayed.
        SecondName.sendKeys("123");
        blanket.click();
        WebElement SecondNameNumbers = driver.get().findElement(By.xpath("//*[contains(text(), 'Please enter a valid last name')]"));
        boolean SecondNameNumbersErrorVisible = SecondNameNumbers.isDisplayed();
        softAssert.assertTrue(SecondNameNumbersErrorVisible);
        SecondName.sendKeys(select);
        SecondName.sendKeys(Keys.DELETE);

        // Send special characters into SecondName, and then check that the proper error messages are displayed.
        SecondName.sendKeys("%<$£!");
        blanket.click();
        WebElement SecondNameSpecial = driver.get().findElement(By.xpath("//*[contains(text(), 'Please enter a valid last name')]"));
        boolean SecondNameSpecialErrorVisible = SecondNameSpecial.isDisplayed();
        softAssert.assertTrue(SecondNameSpecialErrorVisible);
        SecondName.clear();

        SecondName.sendKeys(select);
        SecondName.sendKeys(Keys.DELETE);

        // Send 51 keys into the Second Name field, and check that the proper error message is displayed, then clear down the box.
        SecondName.sendKeys(StringUtils.repeat("a", 51));
        System.out.println("51 Keys have been input");
        WebElement FiftyOneKeys = driver.get().findElement(By.xpath("//*[contains(text(), 'Last name cannot be longer than 50 characters')]"));
        boolean FiftyOneKeysErrorVisible = FiftyOneKeys.isDisplayed();
        softAssert.assertTrue(FiftyOneKeysErrorVisible);
        SecondName.sendKeys(select);
        SecondName.sendKeys(Keys.DELETE);

        SecondName.sendKeys("ABC1");
        SecondName.sendKeys(select);
        SecondName.sendKeys(Keys.DELETE);

        SecondName.sendKeys("AutomatedTest");

        softAssert.assertAll();
    }

    public void EnterEmail() {
        // Create a string that contains the action "Control + A" on a keyboard
       // String select = Keys.chord(Keys.COMMAND, Keys.CONTROL, "a");
        String select = Keys.chord(Keys.SHIFT, Keys.ARROW_UP);
        
        WebElement blanket = driver.get().findElement(By.xpath("//html"));

        // Ensure that you can find the email element
        WebElement email = driver.get().findElement(By.name("email"));
        boolean emailVisible = email.isDisplayed();
        softAssert.assertTrue(emailVisible);
        //click into the box, send a blank value and then click anywhere on the field, check the error message shows
        email.sendKeys("");
        blanket.click();
        WebElement EmailBlankError = driver.get().findElement(By.xpath("//*[contains(text(), 'Please enter an email address')]"));
        boolean emailBlankErrorVisible = EmailBlankError.isDisplayed();
        softAssert.assertTrue(emailBlankErrorVisible);
        // Send 101 keys into the First Name field, and check that the proper error message is displayed, then clear down the box.
        email.sendKeys(StringUtils.repeat("a", 101));
        System.out.println("101 keys have been input in the email field");
        blanket.click();
        WebElement OneohOneKeysError = driver.get().findElement(By.xpath("//*[contains(text(),'Email address cannot be longer than 100 characters')]"));
        boolean OneohOneKeysErrorVisible = OneohOneKeysError.isDisplayed();
        softAssert.assertTrue(OneohOneKeysErrorVisible);
        //Enter an invalid email into the email field and ensure that the correct error message displays
        email.sendKeys(select);
        email.sendKeys(Keys.DELETE);
        email.sendKeys("test@test@gmail.com");
        WebElement EmailInvalidError = driver.get().findElement(By.xpath("//*[contains(text(), 'Please enter a valid email address')]"));
        boolean emailInvalidErrorVisible = EmailInvalidError.isDisplayed();
        softAssert.assertTrue(emailInvalidErrorVisible);
        String emailInvalidErrorText = EmailInvalidError.getText();
        softAssert.assertEquals(emailInvalidErrorText, "Please enter a valid email address");

        email.sendKeys(select);
        email.sendKeys(Keys.DELETE);
        email.sendKeys("test@gmail.com");

        softAssert.assertAll();
    }
    public void Fill_in_ContactField(){
        // Create a string that contains the action "Control + A" on a keyboard
        //String select = Keys.chord(Keys.COMMAND, Keys.CONTROL, "a");
        String select = Keys.chord(Keys.SHIFT, Keys.ARROW_UP);
        
        WebElement blanket = driver.get().findElement(By.xpath("//html"));

        // Ensure that you can find the contactNumber field
        WebElement contactNum = driver.get().findElement(By.name("contactNumber"));
        boolean contactNumVisible = contactNum.isDisplayed();
        softAssert.assertTrue(contactNumVisible);

        contactNum.sendKeys("$£%&");
        blanket.click();
        WebElement contactNumError = driver.get().findElement(By.xpath("//*[contains(text(), 'Please enter a valid contact number')]"));
        boolean contactNumErrorVisible = contactNumError.isDisplayed();
        softAssert.assertTrue(contactNumErrorVisible);

        contactNum.sendKeys("-441234567890");
        blanket.click();
        softAssert.assertTrue(contactNumErrorVisible);
        contactNum.sendKeys(select);
        contactNum.sendKeys(Keys.DELETE);

        contactNum.sendKeys("+5941234567890");
        blanket.click();
        contactNum.getCssValue("class");
        softAssert.assertTrue(contactNumErrorVisible);
        contactNum.sendKeys(select);
        contactNum.sendKeys(Keys.DELETE);

        contactNum.sendKeys("+911234567890");
        blanket.click();
        String caseVal = contactNum.getAttribute("class");
        System.out.println("Printing contact number error "+caseVal);

        softAssert.assertEquals(caseVal, "FormControl__input FormControl__input--valid","Printing for 911234567890");
        contactNum.sendKeys(select);
        contactNum.sendKeys(Keys.DELETE);

        contactNum.sendKeys("+447777777777");
        blanket.click();
        softAssert.assertEquals(caseVal, "FormControl__input FormControl__input--valid","printing for +447777777777");
  
        contactNum.sendKeys(select);
        contactNum.sendKeys(Keys.DELETE);

        contactNum.sendKeys("1234567890");
        blanket.click();
        softAssert.assertEquals(caseVal, "FormControl__input FormControl__input--valid","Printing for1234567890" );

        softAssert.assertAll();
  
    }

    public void Fill_In_PostCode() {
        // Create a string that contains the action "Control + A" on a keyboard
        //String select = Keys.chord(Keys.COMMAND, Keys.CONTROL, "a");

        String select = Keys.chord(Keys.SHIFT, Keys.ARROW_UP);
        WebElement blanket = driver.get().findElement(By.xpath("//html"));

        // Ensure that you can find the postcodeber field
        WebElement postcode = driver.get().findElement(By.name("postcode"));
        boolean postcodeVisible = postcode.isDisplayed();
        softAssert.assertTrue(postcodeVisible);

        postcode.sendKeys("NE128ET");
        blanket.click();
        String caseValid = postcode.getAttribute("class");
        softAssert.assertEquals(caseValid, "FormControl__input FormControl__input--valid");
        postcode.sendKeys(select);
        postcode.sendKeys(Keys.DELETE);

        postcode.sendKeys("NE12 8ET");
        blanket.click();
        softAssert.assertEquals(caseValid, "FormControl__input FormControl__input--valid");
        postcode.sendKeys(select);
        postcode.sendKeys(Keys.DELETE);

        postcode.sendKeys("123 456");
        blanket.click();
        String caseInvalid = postcode.getAttribute("class");
        softAssert.assertEquals(caseInvalid, "FormControl__input FormControl__input--invalid");
        WebElement postcodeError = driver.get().findElement(By.xpath("//*[contains(text(), 'Please enter a valid postcode')]"));
        boolean postcodeErrorVisible = postcodeError.isDisplayed();
        softAssert.assertTrue(postcodeErrorVisible);
        postcode.sendKeys(select);
        postcode.sendKeys(Keys.DELETE);

        postcode.sendKeys("TEST");
        blanket.click();
        softAssert.assertEquals(caseInvalid, "FormControl__input FormControl__input--invalid");
        softAssert.assertTrue(postcodeErrorVisible);
        postcode.sendKeys(select);
        postcode.sendKeys(Keys.DELETE);

        postcode.sendKeys("%$£!@");
        blanket.click();
        softAssert.assertEquals(caseInvalid, "FormControl__input FormControl__input--invalid");
        softAssert.assertTrue(postcodeErrorVisible);
        postcode.sendKeys(select);
        postcode.sendKeys(Keys.DELETE);

        softAssert.assertAll();
    }

    public void FilterThroughDropdowns() {

        // Create a string that contains the action "Control + A" on a keyboard
        //String select = Keys.chord(Keys.COMMAND, Keys.CONTROL, "a");
        String select = Keys.chord(Keys.SHIFT, Keys.ARROW_UP);
        
        WebElement blanket = driver.get().findElement(By.xpath("//html"));

        // Ensure that you can find the postcodeber field
        WebElement hearAboutUs = driver.get().findElement(By.name("whereDidYouHearAboutUs"));
        boolean hearAboutUsVisible = hearAboutUs.isDisplayed();
        softAssert.assertTrue(hearAboutUsVisible);

        Select dropdown = new Select(driver.get().findElement(By.name("whereDidYouHearAboutUs")));
        int NoOfDropdowns = dropdown.getOptions().size() - 1;
        WebElement firstOption = dropdown.getFirstSelectedOption();
        String firstOptionText = firstOption.getText();
        System.out.println("Printing the first select option firstOptionText "+firstOptionText);
        softAssert.assertEquals(firstOptionText, "Please select an option");

        hearAboutUs.click();
        blanket.click();
        WebElement getBackToMe = driver.get().findElement(By.xpath("//*[contains(text(), 'Get back to me')]"));
        getBackToMe.click();
        WebElement dropdownError = driver.get().findElement(By.xpath("//*[contains(text(), 'Please select a valid option')]"));
        
        boolean dropdownErrorVisible = dropdownError.isDisplayed();
        softAssert.assertTrue(dropdownErrorVisible);
        softAssert.assertEquals(dropdownError.getText(),"Please select a valid option for where you heard about us");
        for (int i = 1; i < NoOfDropdowns; i++) {
            dropdown.selectByIndex(i);
        }
//        var selectedOptions = dropdown.getAllSelectedOptions();
//        Assert.assertEquals(1, selectedOptions.size());

        softAssert.assertAll();
    }

    public void Check_Checkboxes() {
        WebElement getMoreInformation = driver.get().findElement(By.xpath("//*[contains(text(),'Get more information')]"));
        boolean getMoreInformationDisplayed = getMoreInformation.isDisplayed();
        softAssert.assertTrue(getMoreInformationDisplayed);
        getMoreInformation.click();

        WebElement arrangeAVisit = driver.get().findElement(By.xpath("//*[contains(text(), 'Arrange a visit')]"));
        boolean arrangeAVisitVisible = arrangeAVisit.isDisplayed();
        softAssert.assertTrue(arrangeAVisitVisible);
        arrangeAVisit.click();

        WebElement requestACallback = driver.get().findElement(By.xpath("//*[contains(text(),'Request a callback')]"));
        boolean requestACallbackVisible = requestACallback.isDisplayed();
        softAssert.assertTrue(requestACallbackVisible);
        requestACallback.click();

        softAssert.assertAll();
    }

    public void Click_Declaration() {
        //Define by locating the "declaring my interest" button
        WebElement declaration = driver.get().findElement(By.xpath("//*[@class='FormCheck__label-text FormCheck__label-text--small-dark-rounded']"));
        //Check to make sure that the declaration is visible
        boolean declarationVisible = declaration.isDisplayed();
        softAssert.assertTrue(declarationVisible);
        //click into the button twice, in order to produce the error message for it not being ticked.
        declaration.click();
        declaration.click();
        //locate & define the error message
        WebElement declarationError = driver.get().findElement(By.xpath("//*[@class='FormError']"));
        //verify the error message is present (button is unchecked)
        boolean declarationErrorVisible = declarationError.isDisplayed();
        softAssert.assertTrue(declarationErrorVisible);
        //click to turn on the button
        declaration.click();
        softAssert.assertAll();
    }

    public void Click_Get_Back_To_Me() {
        WebElement getBackToMe = driver.get().findElement(By.xpath("//*[contains(text(), 'Get back to me')]"));
        boolean getBackToMeVisible = getBackToMe.isDisplayed();
        softAssert.assertTrue(getBackToMeVisible);
//            comment the below out to not flood the site
//            getBackToMe.click();
//            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
//            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(), 'Your enquiry was successful')]")));
        softAssert.assertAll();
    }
}



