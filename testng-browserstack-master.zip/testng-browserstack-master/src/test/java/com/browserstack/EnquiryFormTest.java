package com.browserstack;


import com.baseclasses.FormBase;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.time.Duration;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;

public class EnquiryFormTest extends FormBase {
    SoftAssert softAssert = new SoftAssert();
    FormBase fb = new FormBase();
    @Test(priority = 0)
    public void Go_To_Enquiry_Form_And_Fill_In_First_Name() throws InterruptedException {
        WebElement dreamTitle = driver.get().findElement(By.xpath("(//*[contains(text(), 'dream')])"));

        boolean dreamTitleVisible = dreamTitle.isDisplayed();
        softAssert.assertTrue(dreamTitleVisible);

        System.out.println("Printing home page title "+ driver.get().getTitle());
        // Navigate to the Make an Enquiry Page
        WebElement enquireButton = driver.get().findElement(By.xpath("//*[contains(text(), 'Make an enquiry')]"));
        enquireButton.click();

        //Check to make sure you're on the right page
/*
        WebElement enquireText = new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.visibilityOf(driver.get().findElement(By.xpath("(//*[contains(text(), 'Enquire about Persona homes')])[2]"))));
*/
       //driver.get().manage().wait(1000);
       driver.get().manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
       WebElement enquireText = driver.get().findElement(By.xpath("//li[contains(text(), 'Enquire about Persona homes')]"));
        boolean enquireTextVisible = enquireText.isDisplayed();
        softAssert.assertTrue(enquireTextVisible);
        //Print out the Title of the page
       /* String EnquireTitle = driver.get().getTitle();
        System.out.println(EnquireTitle);
*/

        System.out.println("Printing enquiry page title title "+ driver.get().getTitle());
        //FormBase fb = new FormBase();
        fb.EnterFirstName();

        softAssert.assertAll();
    }
    @Test(priority = 1)
    public void Go_To_Enquiry_Form_And_Fill_In_Second_Name() {
        fb.EnterSurname();
    }

    @Test(priority = 2)
    public void Go_To_Enquiry_Form_And_Fill_In_The_Email_Address() {
        fb.EnterEmail();
    }

    @Test(priority = 3)
    public void Go_To_Enquiry_Form_And_Fill_In_Contact_Field()  {
        fb.Fill_in_ContactField();
    }

    @Test(priority = 4)
    public void Go_To_Enquiry_Form_And_Fill_In_PostCode() {
        fb.Fill_In_PostCode();
    }

    @Test(priority = 5)
    public void Go_To_The_Enquiry_Page_And_Filter_Through_The_Dropdowns_in_the_Form() {
        fb.FilterThroughDropdowns();
    }

    @Test(priority = 6)
    public void Go_To_The_Enquiry_Page_And_Click_The_Checkboxes() {
        fb.Check_Checkboxes();
    }

    @Test(priority = 7)
    public void Go_To_The_Enquiry_Page_And_Click_The_Declaration() {
        fb.Click_Declaration();
    }

    @Test(priority = 8)
    public void Go_To_The_Enquiry_Page_And_Click_The_Get_Back_To_Me_Button() {
        fb.Click_Get_Back_To_Me();
    }
}

//span[contains(text(),'']